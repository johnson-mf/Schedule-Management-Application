package DBAccess;

import Database.DBConnection;
import Model.Appointments;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.time.*;
import java.time.temporal.ChronoUnit;
/**This is the database access class that handles everything appointments. */
public class DBAppointments {
    // method that returns the observable list "appointmentsList"
    /**This method gets all the appointments in the database and brings them back in an observable array list. We get the
     * column names: Appointment_ID, Title, Description, Location, Type, Start, End, Create_Date, Created_By, Last_Update,
     * Last_Updated_By, Customer_ID, User_ID, Contact_ID*/
    public static ObservableList<Appointments> getAllAppointments(){
        ObservableList<Appointments> appointmentsList = FXCollections.observableArrayList();


        try{

            //select all countries in the sql database string
            //String sql = "SELECT Appointment_ID, Customer_ID ,Title, Description, Location, contacts.Contact_Name, Type, Start , End ,appointments.Contact_ID,appointments.User_ID FROM appointments, contacts WHERE contacts.Contact_ID = appointments.Customer_ID";
            String sql = " SELECT Appointment_ID, Customer_ID ,Title, Description, Location, contacts.Contact_Name, Type, Start , End ,appointments.Contact_ID,appointments.User_ID FROM appointments, contacts WHERE appointments.Contact_ID = contacts.Contact_ID;";
            //does the db connection
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);

            //the prepared statement with the sql string we created will return a result set

            ResultSet rs = ps.executeQuery();

            //we loop through the results set and get the country id and names and append it to a new countries object
            while(rs.next()){
                int appointmentID = rs.getInt("Appointment_ID");
                int appointmentCustomerId = rs.getInt("Customer_ID");
                String appointmentTitle = rs.getString("Title");
                String appointmentDescription = rs.getString("Description");
                String appointmentLocation = rs.getString("Location");
                String appointmentContact = rs.getString("Contact_Name");
                String appointmentType = rs.getString("Type");
                Timestamp appointmentStart = rs.getTimestamp("Start");
                Timestamp appointmentEnd = rs.getTimestamp("End");
                int appointmentContactID = rs.getInt("Contact_ID");
                int appointmentUserID = rs.getInt("User_ID");

                //timestamp utc to zoned date time to local date time
                //get the zone id of whatever machine is in use
                ZoneId zoneID = ZoneId.systemDefault();
                //convert timestamps to the local dates & times
                LocalDate appointmentStartLD = appointmentStart.toInstant().atZone(zoneID).toLocalDate();
                LocalDate appointmentEndLD = appointmentEnd.toInstant().atZone(zoneID).toLocalDate();
                LocalTime appointmentStartLT = appointmentStart.toInstant().atZone(zoneID).toLocalTime();
                LocalTime appointmentEndLT = appointmentEnd.toInstant().atZone(zoneID).toLocalTime();

                //convert local dates and local times to a local date time
                LocalDateTime appointmentStartLDT = LocalDateTime.of(appointmentStartLD,appointmentStartLT);
                LocalDateTime appointmentEndLDT =LocalDateTime.of(appointmentEndLD,appointmentEndLT);

                Appointments newAppointment = new Appointments (appointmentID,appointmentCustomerId,appointmentTitle,appointmentDescription,appointmentLocation,appointmentType,appointmentStartLDT,appointmentEndLDT,appointmentContactID,appointmentUserID);
                newAppointment.contactName = appointmentContact;

                appointmentsList.add(newAppointment);


            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        catch (NullPointerException e) {

        }


        return appointmentsList;
    }


    /**This method creates a new appointment and doesnt bring anything back. We get the
     * column names: Appointment_ID, Title, Description, Location, Type, Start, End, Customer_ID, User_ID, Contact_ID from the
     * textfields, datepickers, or comboboxes and use a sql statement to insert them into the database*/
    public static void createAppointment (String title, String description, String location, String type, Timestamp start, Timestamp end, int Customer_ID, int User_ID, int Contact_ID){
        try{
            //SQL string
            String sql = "INSERT INTO appointments VALUES(Null, ?,?,?,?,?,?, Null, Null,Null,Null,?,?,?);";
            // we pass in 2 statements because we want the generated key back as well
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            //add to the question marks
            ps.setString(1, title);
            ps.setString(2, description);
            ps.setString(3,location);
            ps.setString(4,type);
            ps.setTimestamp(5,start);
            ps.setTimestamp(6,end);
            ps.setInt(7,Customer_ID);
            ps.setInt(8,User_ID);
            ps.setInt(9, Contact_ID);

            ps.execute();

            ResultSet rs = ps.getGeneratedKeys();
            rs.next();

            //get the integer the database assigns automatically
            int appointmentID = rs.getInt(1);

        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    /**This method modifies an appointment and doesnt bring anything back. We get the
     * column names: Appointment_ID, Title, Description, Location, Type, Start, End, Customer_ID, User_ID, Contact_ID from the
     * textfields, datepickers, or comboboxes and use a sql statement to modify the appointment and put them in the  database*/
    public static void modifyAppointment (String appointmentID , String title, String description, String location, String type, Timestamp start, Timestamp end, int Customer_ID, int User_ID, int Contact_ID){
        try{
            //SQL string
            String sql = "UPDATE appointments set Title=?,Description=?,Location=?,Type=?,Start=?,End=?, Customer_ID=?,User_ID=?,Contact_ID=? WHERE Appointment_ID =?;";


            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            //add to the question marks
            ps.setString(1, title);
            ps.setString(2, description);
            ps.setString(3,location);
            ps.setString(4,type);
            ps.setTimestamp(5,start);
            ps.setTimestamp(6,end);
            ps.setInt(7,Customer_ID);
            ps.setInt(8,User_ID);
            ps.setInt(9, Contact_ID);
            ps.setString(10,appointmentID);

            ps.execute();

            ResultSet rs = ps.getGeneratedKeys();
            rs.next();

        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    /**This method deletes an appointment from the database and does not bring anything back. */
    public static void deleteAppointment (int appointmentID){
        try{
            //SQL string
            String sql = "DELETE from appointments WHERE Appointment_ID = ?;";
            // we pass in 2 statements because we want the generated key back as well
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            //add to the question marks
            ps.setInt(1, appointmentID);


            ps.execute();


        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    /**The getAppointmentByUser method is used in the Consultant Reports page when generating  a tableview of appointments that are sorted by user id
     *  */
    public static ObservableList<Appointments> getAppointmentsByUSer(int userID){
        ObservableList<Appointments> appointmentsList = FXCollections.observableArrayList();

        try{

            //select all countries in the sql database string
            String sql = "select * from appointments where User_ID = ?;";

            //does the db connection
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            ps.setInt(1 , userID);
            //the prepared statement with the sql string we created will return a result set

            ResultSet rs = ps.executeQuery();

            //we loop through the results set and get the country id and names and append it to a new countries object
            while(rs.next()){
                int appointmentID = rs.getInt("Appointment_ID");
                int customerID = rs.getInt("Customer_ID");
                String title = rs.getString("Title");
                String description = rs.getString("Description");
                String location = rs.getString("Location");
                String type = rs.getString("Type");
                Timestamp start = rs.getTimestamp("Start");
                Timestamp end = rs.getTimestamp("End");
                int userIDD = rs.getInt("User_ID");
                int contactID = rs.getInt("Contact_ID");
                //timestamp utc to zoned date time to local date time
                //get the zone id of whatever machine is in use
                ZoneId zoneID = ZoneId.systemDefault();
                //convert timestamps to the local dates & times
                LocalDate appointmentStartLD = start.toInstant().atZone(zoneID).toLocalDate();
                LocalDate appointmentEndLD = end.toInstant().atZone(zoneID).toLocalDate();
                LocalTime appointmentStartLT = start.toInstant().atZone(zoneID).toLocalTime();
                LocalTime appointmentEndLT = end.toInstant().atZone(zoneID).toLocalTime();

                //convert local dates and local times to a local date time
                LocalDateTime appointmentStartLDT = LocalDateTime.of(appointmentStartLD,appointmentStartLT);
                LocalDateTime appointmentEndLDT =LocalDateTime.of(appointmentEndLD,appointmentEndLT);

                Appointments newAppointment = new Appointments (appointmentID,customerID,title,description,location,type,appointmentStartLDT,appointmentEndLDT,contactID,userIDD);
                //newAppointment.contactName = appointmentContact;

                appointmentsList.add(newAppointment);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


        return appointmentsList;
    }

    /**The getAppointmentsByCustomer method is used in the Customers Reports page when generating  a tableview of appointments that are sorted by customer id
     *  */
    public static ObservableList<Appointments> getAppointmentsByCustomer(int customerID){
        ObservableList<Appointments> appointmentsList = FXCollections.observableArrayList();

        try{

            //select all countries in the sql database string
            String sql = "select * from appointments where Customer_ID = ?;";

            //does the db connection
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            ps.setInt(1 , customerID);
            //the prepared statement with the sql string we created will return a result set

            ResultSet rs = ps.executeQuery();

            //we loop through the results set and get the country id and names and append it to a new countries object
            while(rs.next()){
                int appointmentID = rs.getInt("Appointment_ID");
                int customerIDD = rs.getInt("Customer_ID");
                String title = rs.getString("Title");
                String description = rs.getString("Description");
                String location = rs.getString("Location");
                String type = rs.getString("Type");
                Timestamp start = rs.getTimestamp("Start");
                Timestamp end = rs.getTimestamp("End");
                int userIDD = rs.getInt("User_ID");
                int contactID = rs.getInt("Contact_ID");
                //timestamp utc to zoned date time to local date time
                //get the zone id of whatever machine is in use
                ZoneId zoneID = ZoneId.systemDefault();
                //convert timestamps to the local dates & times
                LocalDate appointmentStartLD = start.toInstant().atZone(zoneID).toLocalDate();
                LocalDate appointmentEndLD = end.toInstant().atZone(zoneID).toLocalDate();
                LocalTime appointmentStartLT = start.toInstant().atZone(zoneID).toLocalTime();
                LocalTime appointmentEndLT = end.toInstant().atZone(zoneID).toLocalTime();

                //convert local dates and local times to a local date time
                LocalDateTime appointmentStartLDT = LocalDateTime.of(appointmentStartLD,appointmentStartLT);
                LocalDateTime appointmentEndLDT =LocalDateTime.of(appointmentEndLD,appointmentEndLT);

                Appointments newAppointment = new Appointments (appointmentID,customerIDD,title,description,location,type,appointmentStartLDT,appointmentEndLDT,contactID,userIDD);
                //newAppointment.contactName = appointmentContact;

                appointmentsList.add(newAppointment);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


        return appointmentsList;
    }


    /**This method is used to generate a warning message whether a user has an appointment coming up within 15 minutes or if the there are no new alerts.
     * This method is also used via the lambda excpression in the main menu controller.*/
    public static String getAppointmentMessage(){




        ObservableList<Appointments> appointmentsList = FXCollections.observableArrayList();


        try{

            //select all countries in the sql database string
            String sql = "SELECT Appointment_ID, Customer_ID ,Title, Description, Location, contacts.Contact_Name, Type, Start , End ,appointments.Contact_ID,appointments.User_ID FROM appointments, contacts WHERE contacts.Contact_ID = appointments.Customer_ID";

            //does the db connection
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);

            //the prepared statement with the sql string we created will return a result set

            ResultSet rs = ps.executeQuery();

            //we loop through the results set and get the country id and names and append it to a new countries object
            while(rs.next()){
                int appointmentID = rs.getInt("Appointment_ID");
                int appointmentCustomerId = rs.getInt("Customer_ID");
                String appointmentTitle = rs.getString("Title");
                String appointmentDescription = rs.getString("Description");
                String appointmentLocation = rs.getString("Location");
                String appointmentContact = rs.getString("Contact_Name");
                String appointmentType = rs.getString("Type");
                Timestamp appointmentStart = rs.getTimestamp("Start");
                Timestamp appointmentEnd = rs.getTimestamp("End");
                int appointmentContactID = rs.getInt("Contact_ID");
                int appointmentUserID = rs.getInt("User_ID");

                //timestamp utc to zoned date time to local date time
                //get the zone id of whatever machine is in use
                ZoneId zoneID = ZoneId.systemDefault();
                //convert timestamps to the local dates & times
                LocalDate appointmentStartLD = appointmentStart.toInstant().atZone(zoneID).toLocalDate();
                LocalDate appointmentEndLD = appointmentEnd.toInstant().atZone(zoneID).toLocalDate();
                LocalTime appointmentStartLT = appointmentStart.toInstant().atZone(zoneID).toLocalTime();
                LocalTime appointmentEndLT = appointmentEnd.toInstant().atZone(zoneID).toLocalTime();

                //convert local dates and local times to a local date time
                LocalDateTime appointmentStartLDT = LocalDateTime.of(appointmentStartLD,appointmentStartLT);
                LocalDateTime appointmentEndLDT =LocalDateTime.of(appointmentEndLD,appointmentEndLT);

                Appointments newAppointment = new Appointments (appointmentID,appointmentCustomerId,appointmentTitle,appointmentDescription,appointmentLocation,appointmentType,appointmentStartLDT,appointmentEndLDT,appointmentContactID,appointmentUserID);
                newAppointment.contactName = appointmentContact;

                appointmentsList.add(newAppointment);
                LocalTime currentTime =LocalTime.now();

                for (Appointments appointments : appointmentsList) {

                    LocalTime  start = appointmentStartLDT.toLocalTime();
                    long timeDifference = ChronoUnit.MINUTES.between(start,currentTime);
                    long interval = (timeDifference + -1) * -1;
                   // System.out.println("Interval "+ interval + "time difference " +timeDifference );

                    if (interval > 0 && interval <= 15) {

                        String message = "You have an appointment in " + interval + " minute(s)!";
                        return message;
                    }

                }//String message = "No appointments within the next 15 minutes!";
                //System.out.println(message);

               // return message;

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        catch (NullPointerException e) {

        }


        //return message;
        String message = "No appointments within the next 15 minutes!";
        return message;
    }


}

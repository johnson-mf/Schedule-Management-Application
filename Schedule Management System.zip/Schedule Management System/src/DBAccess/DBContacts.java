package DBAccess;

import Database.DBConnection;
import Model.Appointments;
import Model.Contacts;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**This is the database access class that handles everything customers. */
public class DBContacts {
    /**This method gets all the customers in the database and brings them back in an observable array list. We get the
     * column names: Customer_Name, Email and Customer_ID. This method is used when an observable list is needed for the contact
     * combobox.*/
    public static ObservableList<Contacts> getAllContacts(){
    ObservableList<Contacts> contactsList = FXCollections.observableArrayList();


    try{

        //select all countries in the sql database string
        String sql = "SELECT * from contacts";

        //does the db connection
        PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);

        //the prepared statement with the sql string we created will return a result set

        ResultSet rs = ps.executeQuery();

        //we loop through the results set and get the country id and names and append it to a new countries object
        while(rs.next()){
            int contactID = rs.getInt("Contact_ID");
            String contactName = rs.getString("Contact_Name");
            String contactEmail = rs.getString("Email");

            Contacts newContact = new Contacts (contactID,contactName,contactEmail);
            contactsList.add(newContact);
        }
    } catch (SQLException throwables) {
        throwables.printStackTrace();
    }


    return contactsList;
}
}

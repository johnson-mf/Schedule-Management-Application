package DBAccess;

import Database.DBConnection;
import Model.Users;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**This is the database access class that handles everything users.. */
public class DBUsers {

    /**This method gets all the users in the database and brings them back in an observable array list. We get the
     * column names: Name and ID. This method is used when an observable list is needed to populate the users combo box.
     * */
    public static ObservableList<Users> getAllUsers(){
        ObservableList<Users> userList = FXCollections.observableArrayList();


        try{

            //select all countries in the sql database string
            String sql = "SELECT * from users";

            //does the db connection
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);

            //the prepared statement with the sql string we created will return a result set

            ResultSet rs = ps.executeQuery();

            //we loop through the results set and get the country id and names and append it to a new countries object
            while(rs.next()){
                int userID = rs.getInt("User_ID");
                String userName = rs.getString("User_Name");
                String password = rs.getString("Password");

                Users newUser = new Users (userID,userName,password);
                userList.add(newUser);

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


        return userList;
    }
}

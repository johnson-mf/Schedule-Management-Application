package DBAccess;
import Database.DBConnection;
import Model.Countries;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

/**This is the database access class that handles everything countries. */
public class DBCountries {


    /**This method gets all the countries in the database and brings them back in an observable array list. We get the
     * column names: Name and ID. This method is used when an observable list is needed to populate the countries combo box.
     * */
    // method that returns the observable list "countryList" (country list)
    public static ObservableList<Countries> getAllCountries(){
        ObservableList<Countries> countryList = FXCollections.observableArrayList();


        try{

            //select all countries in the sql database string
            String sql = "SELECT * from countries";

            //does the db connection
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);

            //the prepared statement with the sql string we created will return a result set

            ResultSet rs = ps.executeQuery();

            //we loop through the results set and get the country id and names and append it to a new countries object
            while(rs.next()){
                int countryID = rs.getInt("Country_ID");
                String countryName = rs.getString("Country");
                Countries newCountry = new Countries (countryID, countryName);
                countryList.add(newCountry);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return countryList;
    }



}

package DBAccess;

import Database.DBConnection;
import Model.Contacts;
import Model.Divisions;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**This is the database access class that handles everything divisions. */
public class DBDivisions {

    /**This method gets all the divisions in the database and brings them back in an observable array list. We get the
     * column names: Name and ID and Country_ID. This method is used when an observable list is needed to populate the divisions combo box.
     * */
    public static ObservableList<Divisions> getAllDivisions(){
        ObservableList<Divisions> divisionsList = FXCollections.observableArrayList();


        try{

            //select all countries in the sql database string
            String sql = "SELECT * from first_level_divisions";

            //does the db connection
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);

            //the prepared statement with the sql string we created will return a result set

            ResultSet rs = ps.executeQuery();

            //we loop through the results set and get the country id and names and append it to a new countries object
            while(rs.next()){
                int divisionID = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");
                int divisionCountryID = rs.getInt("COUNTRY_ID");

                Divisions newDivision = new Divisions (divisionID,divisionName,divisionCountryID);
                divisionsList.add(newDivision);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


        return divisionsList;
    }

    /**This method is used for the division combobox once a user selects a country from the previous combobox. This is simply for ease of access
     * and it's only purpose is to make selecting a division id a little bit easier. */
    public static ObservableList<Divisions> getDivisionsByCountry(int countryID){
        ObservableList<Divisions> divisionsList = FXCollections.observableArrayList();


        try{

            //select all countries in the sql database string
            String sql = "select * from first_level_divisions where Country_ID = ?;";

            //does the db connection
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            ps.setInt(1 , countryID);
            //the prepared statement with the sql string we created will return a result set

            ResultSet rs = ps.executeQuery();

            //we loop through the results set and get the country id and names and append it to a new countries object
            while(rs.next()){
                int divisionID = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");
                int divisionCountryID = rs.getInt("COUNTRY_ID");

                Divisions newDivision = new Divisions (divisionID,divisionName,divisionCountryID);
                divisionsList.add(newDivision);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


        return divisionsList;
    }


}

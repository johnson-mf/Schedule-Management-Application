package DBAccess;

import Database.DBConnection;
import Model.Countries;
import Model.Customers;
import Model.Divisions;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
/**This is the database access class that handles everything customers. */
public class DBCustomers {

    /**This method gets all the customers in the database and brings them back in an observable array list. We get the
     * column names: Customer_ID, Customer_Name, Address, Postal_Code, Phone, Create_Date, Created_By, Last_Update, Last_Updated_By,
     * Division_ID*/
    // method that returns the observable list "customerList" (customer list)
    public static ObservableList<Customers> getAllCustomers(){
        ObservableList<Customers> customerList = FXCollections.observableArrayList();


        try{

            //select all countries in the sql database string
            String sql = "SELECT Customer_ID, Customer_Name, Address, Phone, Postal_Code, Division,customers.Division_ID,Country_ID FROM customers, first_level_divisions WHERE customers.Division_ID = first_level_divisions.Division_ID" ;

            //does the db connection
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);

            //the prepared statement with the sql string we created will return a result set

            ResultSet rs = ps.executeQuery();

            //we loop through the results set and get the country id and names and append it to a new countries object
            while(rs.next()){
                int customerID = rs.getInt("Customer_ID");
                String customerName = rs.getString("Customer_Name");
                String customerAddress = rs.getString("Address");
                String customerPhone = rs.getString("Phone");
                String customerZipcode = rs.getString("Postal_Code");
                String customerDivisionName = rs.getString("Division");
                int customerDivisionID= rs.getInt("Division_ID");
                int customerCountryID = rs.getInt("Country_ID");
                Customers newCustomer = new Customers (customerID,customerName,customerAddress,customerPhone,customerZipcode,customerDivisionName,customerDivisionID, customerCountryID);

                customerList.add(newCustomer);

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }



        return customerList;
    }

    /**This method creates a new customer and doesnt bring anything back. We get the
     * column names: Name, address, zipcode, phone, and division_ID from the
     * textfields, comboboxes and use a sql statement to insert them into the database*/
    public static void createCustomer (String name, String address, int divisionID, String zipcode, String phone){
        try{
            //SQL string
            String sql = "INSERT INTO customers VALUES(Null, ?,?,?,?, Null, Null,Null,Null,?)";
            // we pass in 2 statements because we want the generated key back as well
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            //add to the question marks
            ps.setString(1, name);
            ps.setString(2, address);
            ps.setString(3,zipcode);
            ps.setString(4,phone);
            ps.setInt(5,divisionID);


            ps.execute();

            ResultSet rs = ps.getGeneratedKeys();
            rs.next();

            //get the integer the database assigns automatically
            int customerID = rs.getInt(1);

        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    /**This method modifies an existing customer and doesnt bring anything back. We get the
     * column names: Name, address, zipcode, phone, and division_ID from the
     * textfields, comboboxes and use a sql statement to insert them into the database*/
    //we use the id to identify which customer we want to delete!
    public static void modifyCustomer (String customerID , String name, String address, int divisionID, String zipcode, String phone){
        try{
            //SQL string
            String sql = "UPDATE customers set Customer_Name=?, Address=?, Postal_Code=?, Phone=?,Division_ID=? WHERE Customer_ID =?";
            // we pass in 2 statements because we want the generated key back as well
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            //add to the question marks
            ps.setString(1, name);
            ps.setString(2, address);
            ps.setString(3,zipcode);
            ps.setString(4,phone);
            ps.setInt(5,divisionID);
            ps.setString(6,customerID);


            ps.execute();


        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    /**This method deletes a customer from the database and does not bring anything back. */
    public static void deleteCustomer (int customerID){
        try{
            //SQL string
            String sql = "DELETE from customers WHERE Customer_ID = ?;";
            // we pass in 2 statements because we want the generated key back as well
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            //add to the question marks
            ps.setInt(1, customerID);


            ps.execute();


        }catch(SQLException e){
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error: Appointments Attached to Customer");
            alert.setContentText("You must delete all the appointments for the customer first!");
            alert.showAndWait();
        }
    }
}

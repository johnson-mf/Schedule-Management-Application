package Interface;

public interface TimeZone {
    //vale retuning abstract method
    String displayMessage();
}

package Interface;

public interface Appointment {

    String appointmentNotification();
}

package Model;

public class Countries {
    private int id;
    private String name;

    /**This class creates the countries objects needed for use within the system.*/
    public Countries (int id, String name){
        this.id = id;
        this.name = name;
    }
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }


    // method so we can see the right information in the combo box
    @Override
    public String toString(){
        return (name);
    }
}

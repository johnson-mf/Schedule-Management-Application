package Model;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.util.Optional;

public class WarningMessage extends Alerts{

    public WarningMessage( String title, String message){
        super( title, message, Alert.AlertType.WARNING);
    }

    @Override
    public boolean generateAlert(){
        alert.showAndWait();
        return false;
    }
}

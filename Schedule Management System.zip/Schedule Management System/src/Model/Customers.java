package Model;

import DBAccess.DBAppointments;
import DBAccess.DBCustomers;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Customers {
    private int id;
    private String name;
    private String address;
    private String phone;
    private String zipcode;
    private String divisionName;
    private int divisionID;
    private int countryID;


    /**This class creates the customers objects needed for use within the system.*/
    public Customers(int id, String name, String address, String phone, String zipcode, String divisionName, int divisionID, int countryID) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.zipcode = zipcode;
        this.divisionName = divisionName;
        this.divisionID=divisionID;
        this.countryID=countryID;
    }


    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getPhone() {
        return phone;
    }

    public String getZipcode() {
        return zipcode;
    }

    public String getDivisionName() {
        return divisionName;
    }

    public int getDivisionID() {
        return divisionID;
    }


    public int getCountryID() {
        return countryID;
    }


    public static Customers lookupCustomerID (int potentialCustomerID) {

        ObservableList<Customers> allCustomers = DBCustomers.getAllCustomers();

        for (Customers c : allCustomers) {
            if (c.getId() == potentialCustomerID) {
                return c;
            }
        }
        return null;
    }


    public static ObservableList<Customers> lookupCustomerName (String potentialCustomerName) {

        ObservableList<Customers> allCustomers = DBCustomers.getAllCustomers();
        ObservableList<Customers> filteredCustomers = FXCollections.observableArrayList();
        for (Customers c : allCustomers) {
            if (c.getName().contains(potentialCustomerName)) {
                filteredCustomers.add(c);

            }
        }
        return filteredCustomers;
    }
    @Override
    public String toString(){
        return (id+ " : " + name);
    }
}

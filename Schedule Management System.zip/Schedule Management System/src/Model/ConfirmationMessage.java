package Model;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.util.Optional;

public class ConfirmationMessage extends Alerts{

    public ConfirmationMessage( String title, String message){

        super(title,message, Alert.AlertType.CONFIRMATION);
    }

    @Override
    public boolean generateAlert(){
        Optional<ButtonType> result = alert.showAndWait();
        return (result.isPresent() && result.get() == ButtonType.OK);
    }
}

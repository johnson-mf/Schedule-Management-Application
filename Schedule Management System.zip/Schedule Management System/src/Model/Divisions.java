package Model;

//States
public class Divisions {
    private int id;
    private String name;
    private int countryId;


    /**This class creates the divisions objects needed for use within the system.*/
    public Divisions(int id, String name, int countryId) {
        this.id = id;
        this.name = name;
        this.countryId = countryId;

    }
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getCountryId() {
        return countryId;
    }
    @Override
    public String toString(){
        return (name);
    }
}

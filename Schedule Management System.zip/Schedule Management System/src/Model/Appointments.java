package Model;

import DBAccess.DBAppointments;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.time.LocalDateTime;

public class Appointments {
    private int appointmentID;
    private int appointmentCustomerID;
    private String title;
    private String description;
    private String location;
    private int appointmentContactID;
    private int appointmentUserID;
    private String type;
    private LocalDateTime start;
    private LocalDateTime end;
    public String contactName;

/**This class creates the appointments objects needed for use within the system.*/
    public Appointments(int appointmentID, int appointmentCustomerID, String title, String description, String location, String type, LocalDateTime start, LocalDateTime end, int appointmentContactID, int appointmentUserID) {
        this.appointmentID = appointmentID;
        this.appointmentCustomerID = appointmentCustomerID;
        this.title = title;
        this.description = description;
        this.location = location;
        this.appointmentContactID = appointmentContactID;
        this.appointmentUserID = appointmentUserID;
        this.type = type;
        this.start = start;
        this.end = end;
    }

    public int getAppointmentID() {
        return appointmentID;
    }

    public int getAppointmentCustomerID() {
        return appointmentCustomerID;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getLocation() {
        return location;
    }

    public int getAppointmentContactID() {
        return appointmentContactID;
    }

    public int getAppointmentUserID() {
        return appointmentUserID;
    }

    public String getType() {
        return type;
    }

    public LocalDateTime getStart() {
        return start;
    }

    public LocalDateTime getEnd() {
        return end;
    }

    public String getContactName() {
        return contactName;
    }

    public static Appointments lookupAppointmentID (int potentialAppointmentID) {

        ObservableList<Appointments> allAppointments = DBAppointments.getAllAppointments();

        for (Appointments a : allAppointments) {
            if (a.getAppointmentID() == potentialAppointmentID) {
                return a;
            }
        }
        return null;
    }
    public static ObservableList<Appointments> lookupAppointmentName (String potentialAppointmentName) {

        ObservableList<Appointments> allAppointments = DBAppointments.getAllAppointments();
        ObservableList<Appointments> filteredAppointments = FXCollections.observableArrayList();

        for (Appointments a : allAppointments) {
            if (a.getTitle().contains(potentialAppointmentName)) {
                filteredAppointments.add(a);

            }
        }
        return filteredAppointments;
    }
}

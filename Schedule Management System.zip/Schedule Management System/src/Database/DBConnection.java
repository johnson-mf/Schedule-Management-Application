package Database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**Access to the database starts here. WGU generated username and passwords grant access to the database everytime the function is called.*/
// set up the interface for the database
public class DBConnection {

    //JDBC URL parts
    private static final String protocol = "jdbc";
    private static final String vendorName = ":mysql:";
    private static final String ipAddress = "//wgudb.ucertify.com/WJ07mAy";
    private static final String dbName = "WJ07mAy";

    //JDBC URL
    private static final String jdbcURL = protocol + vendorName + ipAddress + "?connectionTimeZone=SERVER";

    //Driver and connection interface references
    private static final String MYSQLJBCDriver = "com.mysql.cj.jdbc.Driver";
    private static Connection conn = null;
    private static final String username = "U07mAy";
    private static String password = "53689070267";

    //Start connection method
    public static Connection startConnection(){
        try {
            //will look through he project directory and get the sql driver
            Class.forName(MYSQLJBCDriver);

            //get connection interface
            conn = DriverManager.getConnection(jdbcURL,username,password);
            System.out.println("Connection Successful!");

        } catch (SQLException e){
           e.printStackTrace();
        } catch ( ClassNotFoundException e){
           e.printStackTrace();

        }
       return conn;

    }
    // get connection method
    public static Connection getConnection(){
        return conn;
    }
    //end the database connection
    public static void closeConnection(){
        try{
            conn.close();
            System.out.println("Connection Terminated.");
        }catch(Exception e){
            // do nothing
        }
    }


}

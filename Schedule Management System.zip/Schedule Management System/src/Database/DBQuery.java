package Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class DBQuery {
    //statement reference
    private static PreparedStatement statement;

    //Create statement object that receives a connection object as a parameter
    public static void setPreparedStatement(Connection conn, String sqlStatement) throws SQLException {
        statement = conn.prepareStatement(sqlStatement);
    }

    //return statement object
    public static PreparedStatement getPreparedStatement(){
        return statement;
    }
}

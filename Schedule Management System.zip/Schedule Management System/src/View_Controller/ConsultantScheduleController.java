package View_Controller;

import DBAccess.DBAppointments;
import DBAccess.DBContacts;
import Model.Appointments;
import Model.Contacts;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ResourceBundle;
/**This class shows the consultant schedules*/
public class ConsultantScheduleController implements Initializable {
    Stage stage;
    Parent scene;


    @FXML
    private ComboBox<Contacts> employeeComboBox;

    @FXML
    private TableView<Appointments> consultantTableView;

    @FXML
    private TableColumn<Appointments, Integer> appointmentIdCol;

    @FXML
    private TableColumn<Appointments,Integer> customerIdCol;

    @FXML
    private TableColumn<Appointments, String> titleCol;

    @FXML
    private TableColumn<Appointments, String> descriptionCol;

    @FXML
    private TableColumn<Appointments, String> typeCol;

    @FXML
    private TableColumn<Appointments, LocalDateTime> startCol;

    @FXML
    private TableColumn<Appointments, LocalDateTime> endCol;

    /**This method is triggered when the user chooses an user id from the combo box. The tableview is then populated with
     * appointments and the corresponding data, including the appointment ID, appointment customer id,
     * title, description, type, and start and end times and dates for the selected user that is selected.*/
    @FXML
    void onUser(ActionEvent event) {
       Contacts contacts = employeeComboBox.getValue();
        ObservableList<Appointments> appointmentList = DBAppointments.getAppointmentsByUSer(contacts.getId());
        consultantTableView.setItems(appointmentList);

        appointmentIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        customerIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentCustomerID"));
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        typeCol.setCellValueFactory(new PropertyValueFactory<>("type"));
        startCol.setCellValueFactory(new PropertyValueFactory<>("start"));
        endCol.setCellValueFactory(new PropertyValueFactory<>("end"));
    }

    /**This method goes back to the main screen*/
    @FXML
    void onActionMainMenu(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View_Controller/FXML/MainMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<Contacts> contactList = DBContacts.getAllContacts();
        employeeComboBox.setItems(contactList);

    }
}

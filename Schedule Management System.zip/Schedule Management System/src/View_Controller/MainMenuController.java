package View_Controller;

import DBAccess.DBAppointments;
import DBAccess.DBCustomers;
import Interface.Appointment;
import Model.*;
import View_Controller.Add_Modify.ModifyAppointmentController;
import View_Controller.Add_Modify.ModifyCustomerController;
import com.mysql.cj.protocol.x.SyncFlushDeflaterOutputStream;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.temporal.WeekFields;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;

public class MainMenuController implements Initializable {
    Stage stage;
    Parent scene;


    @FXML
    private TableView<Appointments> appointmentTableView;

    @FXML
    private TableColumn<Appointments, Integer> appointmentIdCol;

    @FXML
    private TableColumn<Appointments, Integer> customerIdCol;

    @FXML
    private TableColumn<Appointments, String> titleCol;

    @FXML
    private TableColumn<Appointments, String> descriptionCol;

    @FXML
    private TableColumn<Appointments, String> locationCol;

    @FXML
    private TableColumn<Appointments, Integer> contactCol;

    @FXML
    private TableColumn<Appointments, String> typeCol;

    @FXML
    private TableColumn<Appointments, LocalDateTime> startCol;

    @FXML
    private TableColumn<Appointments, String> endCol;

    @FXML
    private TableView<Customers> customerTableView;

    @FXML
    private TableColumn<Customers, Integer> customerIdCol2;

    @FXML
    private TableColumn<Customers, String> customerNameCol;

    @FXML
    private TableColumn<Customers, String> addressCol;

    @FXML
    private TableColumn<Customers, String> phoneCol;

    @FXML
    private TableColumn<Customers, String> zipcodeCol;

    @FXML
    private TableColumn<Customers, String> divisionCol;

    @FXML
    private RadioButton currentWeekToggle;

    @FXML
    private ToggleGroup viewToggleGroup;

    @FXML
    private RadioButton currentMonthToggle;

    @FXML
    private RadioButton allViewsToggle;

    @FXML
    private Label alertLabel;

    @FXML
    private TextField customerSearchText;
    @FXML
    private TextField appointmentSearchText;
    /**
     * This method takes you to the screen where you are able to add appointments. The values in the date pickers, combo boxes, and textfields and uses a method in the DBACCESS package to
     * create the appointment. The following values are taking in and saved to the mySQL database: UserID, CustomerID, Title, Description,
     * Location, ContactID, Type, Start and End times and dates. If a user puts in the wrong value or forgets a value, a sql exception is thrown
     * and an error message appears to help guide the user to fix the mistake.
     */
    @FXML
    void onActionAddAppointment(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View_Controller/FXML/AddAppointment.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }


    /**
     * This method takes you to the add customer screen. The values in the date pickers, combo boxes, and textfields and uses a method in the DBACCESS package to
     * create the customer. The following values are taking in and saved to the mySQL database: Name, address, division, country,
     * zipcode, and phone number. If a user puts in the wrong value or forgets a value, a sql exception is thrown
     * and an error message appears to help guide the user to fix the mistake.
     */
    @FXML
    void onActionAddCustomer(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View_Controller/FXML/AddCustomer.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }


    /**
     * This methosd takes you to the appointment types screen, where you can sort appointment types by month.There are 12 methods here each
     * named from a month in the year. When a user selects a radio button, the month correspoinding with that radio button
     * will be used to look in the database and show the appointment formats for the specified month. ALl appointments in the selected
     * month is listed.
     */
    @FXML
    void onActionAppointmentTypes(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View_Controller/FXML/AppointmentTypes.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }


    /**
     * This method will take you to the Consultant schedule screen. From there, the user chooses an user id from the combo box. The tableview is then populated with
     * appointments and the corresponding data, including the appointment ID, appointment customer id,
     * title, description, type, and start and end times and dates for the selected user that is selected.
     */
    @FXML
    void onActionConsultantSchedule(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View_Controller/FXML/ConsultantSchedule.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }


    /**
     * This method will take you to the Customer schedule screen. From there, the user chooses an customer id from the combo box. The tableview is then populated with
     * appointments and the corresponding data, including the appointment ID, appointment user id,
     * title, description, type, and start and end times and dates for the customer that is selected.
     */
    @FXML
    void onActionCustomerAppointments(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View_Controller/FXML/CustomerSchedule.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }


    /**
     * This method deletes an appointment from the table view that is selected. A label will also appear to let the user know which
     * appointment has been cancelled
     */
    @FXML
    void onActionDeleteAppointment(ActionEvent event) {
        Appointments currentAppointment = appointmentTableView.getSelectionModel().getSelectedItem();
        Alerts warning = new ConfirmationMessage("Delete this appointment?","Are you sure you want to delete Appointment ID: "+ currentAppointment.getAppointmentID() + "?" );
        //warning.generateAlert();
        boolean w = warning.generateAlert();
        if(w == true){

             DBAppointments.deleteAppointment(currentAppointment.getAppointmentID());
             appointmentTableView.getItems().remove(currentAppointment);
             alertLabel.setText("Appointment ID: " + currentAppointment.getAppointmentID() + " Type: " + currentAppointment.getType() + " has been deleted.");
        }


        }


    /**
     * This method deletes a customer from the table view that is selected. A label will also appear to let the user know which
     * customer has been deleted
     */
    public ObservableList<Appointments> getAllCustomerAppointments(Customers selectedCustomer){
        ObservableList<Appointments> customerAppointments = FXCollections.observableArrayList();
        ObservableList<Appointments> allAppointments = DBAppointments.getAllAppointments();

        for (Appointments appointment: allAppointments){
            if (appointment.getAppointmentCustomerID() == selectedCustomer.getId()){
                customerAppointments.add(appointment);
            }
        }
        return customerAppointments;
    }

    @FXML
    void onActionDeleteCustomer(ActionEvent event) {

    Customers selectedCustomer = customerTableView.getSelectionModel().getSelectedItem();
    Alerts warning = new ConfirmationMessage("Delete this customer?","Are you sure you want to delete " + selectedCustomer.getName() + "?");
    //warning.generateAlert();
    boolean w = warning.generateAlert();
    if(w == true) {



        if(getAllCustomerAppointments(selectedCustomer).size() == 0){
            DBCustomers.deleteCustomer(selectedCustomer.getId());
            customerTableView.getItems().remove(selectedCustomer);
            alertLabel.setText("Customer ID: " + selectedCustomer.getId() + " has been deleted.");
        }else{
            Alerts errorMessage = new WarningMessage("Couldn't Delete Customer ","You must delete all appointments associated first");
            errorMessage.generateAlert();
        }
        }

    }


    /**
     * Bonus method that goes back to the log in screen
     */
    @FXML
    void onActionLoginScreen(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View_Controller/FXML/Login.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * This method modifies an appointment. The user must select an appointment that  they would like to modify. the taxt fields, combo boxes and
     * other related fields will be prepopulated with the appropriate data. We get the
     * column names:Name, address, zipcode, phone, and division_ID from the
     * textfields, datepickers, or comboboxes and use a sql statement to modify the customer and put them in the  database
     */
    @FXML
    void onActionModifyAppointment(ActionEvent event) throws IOException, SQLException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/View_Controller/FXML/ModifyAppointment.fxml"));
        loader.load();

        // load the data and send it to the table view
        ModifyAppointmentController MPrController = loader.getController();
        MPrController.sendAppointment(appointmentTableView.getSelectionModel().getSelectedItem());

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        //scene = FXMLLoader.load(getClass().getResource("/View_Controller/ModifyCustomer.fxml"));
        Parent scene = loader.getRoot();
        stage.setScene(new Scene(scene));
        stage.show();
    }


    /**
     * This method modifies a customer. The user must select a customer that  they would like to modify. the taxt fields, combo boxes and
     * other related fields will be prepopulated with the appropriate data. We get the
     * column names: Appointment_ID, Title, Description, Location, Type, Start, End, Customer_ID, User_ID, Contact_ID from the
     * textfields, datepickers, or comboboxes and use a sql statement to modify the appointment and put them in the  database
     */
    @FXML
    void onActionModifyCustomer(ActionEvent event) throws IOException, SQLException {
        //Passing information from one controller to another

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/View_Controller/FXML/ModifyCustomer.fxml"));
        loader.load();

        // load the data and send it to the table view
        ModifyCustomerController MPrController = loader.getController();
        MPrController.sendCustomer(customerTableView.getSelectionModel().getSelectedItem());

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        //scene = FXMLLoader.load(getClass().getResource("/View_Controller/ModifyCustomer.fxml"));
        Parent scene = loader.getRoot();
        stage.setScene(new Scene(scene));
        stage.show();
    }


    /**
     * This method gets the current weeks appointments
     */
    public ObservableList<Appointments> getWeeklyAppointments() {
        //create an empty array list and bring us our original array list,

        ObservableList<Appointments> weeklyAppointments = FXCollections.observableArrayList();

        ObservableList<Appointments> allAppointments = DBAppointments.getAllAppointments();

        //allAppointments = appointmentTableView.getItems();

        //run a loop and and delete the parts that are in original list that are not in the selected list
        for (Appointments appointments : allAppointments) {

            //LocalDate today =LocalDate.now();
            LocalDate compareDate = appointments.getStart().toLocalDate();
            WeekFields week = WeekFields.of(Locale.getDefault());
            LocalDate today = LocalDate.now();

            int compareToday = today.get(week.weekOfWeekBasedYear());

            int compareWeek = compareDate.get(week.weekOfWeekBasedYear());
            if (compareToday == compareWeek) {
                weeklyAppointments.add(appointments);
            }
        }

        return weeklyAppointments;
    }


    /**
     * This method gets the current months appointments
     */
    public ObservableList<Appointments> getMonthlyAppointments() {
        //create an empty array list and bring us our original array list,

        ObservableList<Appointments> monthlyAppointments = FXCollections.observableArrayList();

        ObservableList<Appointments> allAppointments = DBAppointments.getAllAppointments();

        //allAppointments = appointmentTableView.getItems();

        //run a loop and and delete the parts that are in original list that are not in the selected list
        for (Appointments appointments : allAppointments) {

            LocalDate today = LocalDate.now();
            Month monthEnd = today.getMonth();
            LocalDate compareDate = appointments.getStart().toLocalDate();
            Month compareMonth = compareDate.getMonth();

            if (compareMonth == monthEnd) {
                monthlyAppointments.add(appointments);
            }
        }

        return monthlyAppointments;
    }


    /**
     * This method gets all the appointments on mouse click
     */

    @FXML
    void onMouseAll(MouseEvent event) {
        appointmentTableView.setItems(DBAppointments.getAllAppointments());
    }

    /**
     * This method gets the current months appointments on mouse click
     */

    @FXML
    void onMouseMonth(MouseEvent event) {
        appointmentTableView.setItems(getMonthlyAppointments());
    }

    /**
     * This method gets the current weeks appointments on mouse click
     */
    @FXML
    void onMouseWeek(MouseEvent event) {
        appointmentTableView.setItems(getWeeklyAppointments());
    }

    @FXML
    void onAppointmentSearch(KeyEvent event){

        // variable "q" is the what the user is trying to search. the method in Appointments class takes a integer
        String q = appointmentSearchText.getText();
        //ObservableList<Appointments> filteredAppointments = FXCollections.observableArrayList();

        //searching for appointment names
        ObservableList<Appointments> filteredAppointmentNames = Appointments.lookupAppointmentName(q);
        appointmentTableView.setItems(filteredAppointmentNames);

        //turning it into an integer in case the user is searching for an ID
        int potentialAppointmentID = Integer.parseInt(q);


        Appointments potentialAppointment = Appointments.lookupAppointmentID(potentialAppointmentID);

        if(potentialAppointment != null){
            filteredAppointmentNames.add(potentialAppointment);
        }
        appointmentTableView.setItems(filteredAppointmentNames);


    }

    @FXML
    void onCustomerSearch(ActionEvent event){
        // variable "q" is the what the user is trying to search. the method in Appointments class takes a integer
        String q = customerSearchText.getText();
        //ObservableList<Appointments> filteredAppointments = FXCollections.observableArrayList();

        //searching for appointment names
        ObservableList<Customers> filteredCustomerNames = Customers.lookupCustomerName(q);
        customerTableView.setItems(filteredCustomerNames);

        //turning it into an integer in case the user is searching for an ID
        int potentialCustomerID = Integer.parseInt(q);


        Customers potentialCustomer = Customers.lookupCustomerID(potentialCustomerID);

        if(potentialCustomer != null){
            filteredCustomerNames.add(potentialCustomer);
        }
        customerTableView.setItems(filteredCustomerNames);

    }





/**This is the second spot that the lambda expression is used. Here, the lambnda expression calls a method in DBACCESS package
 * that checks for any appointments that are coming soon within the next 15 minutes. It returns a string for the program to set
 * the label text to.*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        //lambda alert to show appointment reminders
        Appointment message = () -> DBAppointments.getAppointmentMessage();
        alertLabel.setText(message.appointmentNotification());
        customerTableView.setItems(DBCustomers.getAllCustomers());
        appointmentTableView.setItems(DBAppointments.getAllAppointments());


        customerTableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        appointmentTableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        //APPOINTMENT TABLE
        appointmentIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        customerIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentCustomerID"));
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        locationCol.setCellValueFactory(new PropertyValueFactory<>("location"));
        contactCol.setCellValueFactory(new PropertyValueFactory<>("contactName"));
        typeCol.setCellValueFactory(new PropertyValueFactory<>("type"));
        startCol.setCellValueFactory(new PropertyValueFactory<>("start"));
        endCol.setCellValueFactory(new PropertyValueFactory<>("end"));
        //CUSTOMER TABLE
        customerIdCol2.setCellValueFactory(new PropertyValueFactory<>("id"));
        customerNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        addressCol.setCellValueFactory(new PropertyValueFactory<>("address"));
        phoneCol.setCellValueFactory(new PropertyValueFactory<>("phone"));
        zipcodeCol.setCellValueFactory(new PropertyValueFactory<>("zipcode"));
        divisionCol.setCellValueFactory(new PropertyValueFactory<>("divisionName"));

        allViewsToggle.setSelected(true);


    }
}
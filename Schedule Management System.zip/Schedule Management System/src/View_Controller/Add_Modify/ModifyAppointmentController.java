package View_Controller.Add_Modify;

import DBAccess.DBAppointments;
import DBAccess.DBContacts;
import DBAccess.DBCustomers;
import DBAccess.DBUsers;
import Database.DBConnection;
import Model.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.*;
import java.util.ResourceBundle;

/**This is the modify Appointment screen*/
public class ModifyAppointmentController implements Initializable {
    Stage stage;
    Parent scene;

    @FXML
    private TextField titleTextField;

    @FXML
    private TextField descriptionTextField;

    @FXML
    private TextField locationTextField;

    @FXML
    private TextField typeTextField;

    @FXML
    private ComboBox<LocalTime> startComboBox;

    @FXML
    private ComboBox<LocalTime> endComboBox;

    @FXML
    private  Label warningLabel;

    @FXML
    private ComboBox<Customers> customerIdComboBox;

    @FXML
    private ComboBox<Contacts> contactComboBox;

    @FXML
    private ComboBox<Users> userIdComboBox;

    @FXML
    private Label appointmentIdLabel;

    @FXML
    private DatePicker datepicker;
    ObservableList <Appointments> appointmentsList = DBAppointments.getAllAppointments();
/** This method takes the information from the main controller screen and brings them over to set the appropiate text fields, date pickers and
 * combo boxes */
    public void sendAppointment(Appointments appointments) throws SQLException {
        appointmentIdLabel.setText(String.valueOf(appointments.getAppointmentID()));
        titleTextField.setText(appointments.getTitle());
        descriptionTextField.setText(appointments.getDescription());
        locationTextField.setText(appointments.getLocation());
        typeTextField.setText(appointments.getType());

        //combo boxes
        datepicker.setValue(appointments.getStart().toLocalDate());
        endComboBox.setValue(appointments.getEnd().toLocalTime());
        startComboBox.setValue(appointments.getStart().toLocalTime());
        userIdComboBox.setValue(getUserName(appointments.getAppointmentUserID()));
        customerIdComboBox.setValue(getCustomerName(appointments.getAppointmentCustomerID()));
        contactComboBox.setValue(getContactName(appointments.getAppointmentContactID()));
    }

    /**This method gets all the users in the database and brings them back in an observable array list. We get the
     * column names: Name and ID. This method is used when an observable list is needed to populate the users combo box.
     * */
    //MAke this return a division object
    public static Users getUserName (int userID) throws SQLException {

        ObservableList<Users> userList = FXCollections.observableArrayList();

        try{


            String sql = "Select * from users Where User_ID= ?";

            //does the db connection
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            ps.setInt(1, userID);

            //the prepared statement with the sql string we created will return a result set

            ResultSet rs = ps.executeQuery();


            //we loop through the results set and get the country id and names and append it to a new countries object
            while(rs.next()) {
                int userIDD = rs.getInt("User_ID");
                String username = rs.getString("User_Name");
                String password = rs.getString("Password");


                Users newUser = new Users(userIDD,username,password);
                userList.add(newUser);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return userList.get(0);

    }


    /**This method gets all the customers in the database and brings them back in an observable array list. We get the
     * column names: Name and ID. This method is used when an observable list is needed to populate the customer combo box.
     * */
    public static Customers getCustomerName (int customerID) throws SQLException {

        ObservableList<Customers> customerList = FXCollections.observableArrayList();

        try{


            String sql = "Select * from customers Where Customer_ID= ?";

            //does the db connection
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            ps.setInt(1, customerID);

            //the prepared statement with the sql string we created will return a result set

            ResultSet rs = ps.executeQuery();


            //we loop through the results set and get the country id and names and append it to a new countries object
            while(rs.next()) {
                int customerIDD = rs.getInt("Customer_ID");
                String name = rs.getString("Customer_Name");
                String address = rs.getString("Address");
                String phone = rs.getString("Phone");
                String zipcode = rs.getString("Postal_Code");

                String divisionName = "";
                int divisionID = 0;
                int countryID = 0;


                Customers newCustomer = new Customers(customerIDD,name,address,phone,zipcode,divisionName,divisionID,countryID);

                customerList.add(newCustomer);

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return customerList.get(0);

    }


    /**This method gets all the contacts in the database and brings them back in an observable array list. We get the
     * column names: Name and ID. This method is used when an observable list is needed to populate the contacts combo box.
     * */
    public static Contacts getContactName (int contactID) throws SQLException {

        ObservableList<Contacts> contactList = FXCollections.observableArrayList();

        try{


            String sql = "Select * from contacts Where Contact_ID= ?";

            //does the db connection
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            ps.setInt(1, contactID);

            //the prepared statement with the sql string we created will return a result set

            ResultSet rs = ps.executeQuery();


            //we loop through the results set and get the country id and names and append it to a new countries object
            while(rs.next()) {
                int contactIDD = rs.getInt("Contact_ID");
                String name = rs.getString("Contact_Name");
                String address = rs.getString("Email");


                Contacts newContact = new Contacts(contactIDD,name,address);

                contactList.add(newContact);
                System.out.println(contactList);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return contactList.get(0);

    }

    /**Goes back to the main menu*/
    @FXML
    void onActionCancel(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View_Controller/FXML/MainMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }


/** This method modifies  and saves an appointment  We get the
 * column names: Appointment_ID, Title, Description, Location, Type, Start, End, Customer_ID, User_ID, Contact_ID from the
 * textfields, datepickers, or comboboxes and use a sql statement to modify the appointment and put them in the  database*/
    @FXML
    void onActionMainMenu(ActionEvent event) throws IOException {
        try {
            //Saving the appointment minute 40:00 the keys to keys
            String appointmentID = appointmentIdLabel.getText();
            Users userID = userIdComboBox.getValue();
            Customers customerID = customerIdComboBox.getValue();
            String title = titleTextField.getText();
            String description = descriptionTextField.getText();
            String location = locationTextField.getText();
            Contacts contactID = contactComboBox.getValue();
            String type = typeTextField.getText();
            LocalDate date = datepicker.getValue(); // returns date
            LocalTime start = startComboBox.getValue(); // returns start time
            LocalTime end = endComboBox.getValue(); // returns end time


            //Start time and end time:
            LocalDateTime startLocalDateTime = LocalDateTime.of(date, start);
            LocalDateTime endLocalDateTime = LocalDateTime.of(date, end);
            int currentCustomer =customerIdComboBox.getValue().getId();


            removal();
            for (Appointments appointments: appointmentsList) {


                LocalDateTime existingStart = appointments.getStart();
                LocalDateTime existingEnd = appointments.getEnd();
                if (currentCustomer == appointments.getAppointmentCustomerID()) {
                    if (startLocalDateTime.isAfter(existingStart.minusMinutes(1)) && startLocalDateTime.isBefore(existingEnd)) {
                        warningLabel.setText("Appointment ID:" + appointments.getAppointmentID() + " with a start time of " + appointments.getStart() + " and an end time of  : " + appointments.getEnd() + " already exists.");
                        return;
                    }
                    if (endLocalDateTime.isAfter(existingStart) && endLocalDateTime.isBefore(existingEnd.plusMinutes(1))) {
                        warningLabel.setText("Appointment ID:" + appointments.getAppointmentID() + " with a start time of " + appointments.getStart() + " and an end time of  : " + appointments.getEnd() + " already exists.");
                        return;
                    }
                    if (startLocalDateTime.isBefore(existingStart) && endLocalDateTime.isAfter(existingEnd.plusMinutes(1))) {
                        warningLabel.setText("Appointment ID:" + appointments.getAppointmentID() + " with a start time of " + appointments.getStart() + " and an end time of  : " + appointments.getEnd() + " already exists.");
                        return;
                    }
                }
            }
            DBAppointments.modifyAppointment(appointmentID, title, description, location, type, Timestamp.valueOf(startLocalDateTime), Timestamp.valueOf(endLocalDateTime), customerID.getId(), userID.getId(), contactID.getId());


            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/View_Controller/FXML/MainMenu.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        } catch(NumberFormatException | IOException e){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText("Please enter the right values for the corresponding fields!");
            alert.showAndWait();
        }
    }
    public boolean removal(){
        //ObservableList<Appointments> appointmentsList = DBAppointments.getAllAppointments();
        ObservableList<Appointments> toRemove = FXCollections.observableArrayList();
        String appointmentID = appointmentIdLabel.getText();
        int deleteID = Integer.parseInt(appointmentID);

        for(Appointments appointments : appointmentsList) {
            if (deleteID == appointments.getAppointmentID()) {
                toRemove.add(appointments);
                //System.out.println("Removed" + appointments.getAppointmentID() + appointmentsList);

            }

        }
        return appointmentsList.removeAll(toRemove);
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        //making a list to set the combo boxes to
        ObservableList<Users> userList = DBUsers.getAllUsers();
        userIdComboBox.setItems(userList);

        //making a list to set the combo boxes to
        ObservableList<Customers> customerList = DBCustomers.getAllCustomers();
        customerIdComboBox.setItems(customerList);

        //making a list to set the combo boxes to
        ObservableList<Contacts> contactsList = DBContacts.getAllContacts();
        contactComboBox.setItems(contactsList);

        ZoneId utcZoneID = ZoneId.of("UTC");
        ZoneId userZoneID = ZoneId.systemDefault();

        //create utc local dates and times
        LocalDate utcDate = LocalDate.of(2020,05,06);

        LocalTime utcStartTime =LocalTime.of(12,00);
        LocalTime utcEndTime =LocalTime.of(2,00);

        //turn them into local date times
        LocalDateTime utcStartLocalDateTime = LocalDateTime.of(utcDate,utcStartTime);
        LocalDateTime utcEndLocalDateTime = LocalDateTime.of(utcDate,utcEndTime);

        //turn them into utc zoned date times
        ZonedDateTime utcStartZonedDateTime = ZonedDateTime.of(utcStartLocalDateTime,utcZoneID);
        ZonedDateTime utcEndZonedDateTime = ZonedDateTime.of(utcEndLocalDateTime,utcZoneID);


        //convert utc zoned start and end times to the system default time
        ZonedDateTime systemStartZonedDateTime = ZonedDateTime.ofInstant(utcStartZonedDateTime.toInstant(),userZoneID);
        ZonedDateTime systemEndZonedDateTime = ZonedDateTime.ofInstant(utcEndZonedDateTime.toInstant(),userZoneID);

        //convert system start zoned times to local date times
        LocalDateTime systemStartLocalDateTime = LocalDateTime.ofInstant(systemStartZonedDateTime.toInstant(),userZoneID);
        LocalDateTime systemEndLocalDateTime = LocalDateTime.ofInstant(systemEndZonedDateTime.toInstant(),userZoneID);

        LocalTime start = systemStartLocalDateTime.toLocalTime();
        LocalTime end = systemEndLocalDateTime.toLocalTime();


        //local time
        while(start.isBefore(end.plusSeconds(1))){
            startComboBox.getItems().add(start);
            endComboBox.getItems().add(start);
            start = start.plusMinutes(15);
        }
    }
}
/*

            for (Appointments appointments: appointmentsList){
                if(Integer.parseInt(appointmentID) == appointments.getAppointmentID()){
                    appointmentsList.remove(appointments);
                    System.out.println("Removed" + appointments.getAppointmentID() + appointmentsList);
                    return;
                }*/
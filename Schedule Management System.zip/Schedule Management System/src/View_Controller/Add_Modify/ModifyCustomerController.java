package View_Controller.Add_Modify;

import DBAccess.DBCountries;
import DBAccess.DBCustomers;
import DBAccess.DBDivisions;
import Database.DBConnection;
import Model.Countries;
import Model.Customers;
import Model.Divisions;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ModifyCustomerController implements Initializable {
    Stage stage;
    Parent scene;


    @FXML
    private TextField addressTextField;

    @FXML
    private TextField zipcodeTextField;

    @FXML
    private TextField phoneNumberTextField;

    @FXML
    private TextField customerNameTextField;

    @FXML
    private ComboBox<Countries> countryComboBox;

    @FXML
    private ComboBox<Divisions> divisionComboBox;

    @FXML
    private Label customerIdLabel;

    /** This method takes the information from the main controller screen and brings them over to set the appropiate text fields, date pickers and
     * combo boxes */
    public void sendCustomer(Customers customers) throws SQLException {
        customerIdLabel.setText(String.valueOf(customers.getId()));
        customerNameTextField.setText(customers.getName());
        addressTextField.setText(customers.getAddress());
        zipcodeTextField.setText(customers.getZipcode());
        phoneNumberTextField.setText(customers.getPhone());
        //combo boxes

        divisionComboBox.setValue(getDivisionName(customers.getDivisionID()));
        countryComboBox.setPromptText(getCountryName(customers.getCountryID()));



    }

    /**This method gets all the divisions in the database and brings them back in an observable array list. We get the
     * column names: Name and ID. This method is used when an observable list is needed to populate the divison combo box.
     * */
    //MAke this return a division object
    public static Divisions  getDivisionName (int divisionID) throws SQLException {

        ObservableList<Divisions> divisionNameList = FXCollections.observableArrayList();

        try{


        String sql = "Select * from first_level_divisions Where Division_ID= ?";

        //does the db connection
        PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
        ps.setInt(1, divisionID);

        //the prepared statement with the sql string we created will return a result set

        ResultSet rs = ps.executeQuery();
        //String divisionName= "";

        //we loop through the results set and get the country id and names and append it to a new countries object
        while(rs.next()) {
            int divisionIDD = rs.getInt("Division_ID");
            String divisionName = rs.getString("Division");
            int divisionCountryID = rs.getInt("COUNTRY_ID");

            Divisions newDivision = new Divisions(divisionIDD, divisionName, divisionCountryID);
            divisionNameList.add(newDivision);
        }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return divisionNameList.get(0);

        }


    /**This method gets all the countries in the database and brings them back in an observable array list. We get the
     * column names: Name and ID. This method is used when an observable list is needed to populate the country combo box.
     * */
    //MAke this return a division object
    public static String  getCountryName (int countryID) throws SQLException {

        ObservableList<Countries> countryNameList = FXCollections.observableArrayList();
        String countryDiv = "";


        try{

            String sql2 = "select * from countries where Country_ID = ?;";

            //does the db connection
            PreparedStatement ps2 = DBConnection.getConnection().prepareStatement(sql2);
            ps2.setInt(1, countryID);

            //the prepared statement with the sql string we created will return a result set

            ResultSet rs2 = ps2.executeQuery();

            //countryDiv = rs2.getString("Country");


            //we loop through the results set and get the country id and names and append it to a new countries object
            while(rs2.next()) {
                countryDiv = rs2.getString("Country");

            }


        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        System.out.println(countryNameList);

        return countryDiv;




    }

    public void onCountry(ActionEvent event) {

        Countries countries = countryComboBox.getValue();

        ObservableList<Divisions> divisionsList = DBDivisions.getDivisionsByCountry(countries.getId());
        divisionComboBox.setItems(divisionsList);
    }


    /** This method modifies  and saves an appointment  We get the
     * column names:Name, address, zipcode, phone, and division_ID from the
     * textfields, datepickers, or comboboxes and use a sql statement to modify the appointment and put them in the  database*/
    @FXML
    void onActionMainMenu(ActionEvent event) throws IOException {
        try {
            String id = customerIdLabel.getText();
            String name = customerNameTextField.getText();
            String address = addressTextField.getText();
            Countries country = countryComboBox.getValue();
            Divisions division = divisionComboBox.getValue();
            String zipcode = zipcodeTextField.getText();
            String phone = phoneNumberTextField.getText();

            DBCustomers.modifyCustomer(id, name, address, division.getId(), zipcode, phone);


            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/View_Controller/FXML/MainMenu.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        } catch (NumberFormatException | IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText("Please enter the right values for the corresponding fields!");
            alert.showAndWait();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            //making a list to set the combo boxes to

            ObservableList<Countries> countryList = DBCountries.getAllCountries();
            countryComboBox.setItems(countryList);

            //countryComboBox.setPromptText();


        }
        catch (NullPointerException e) {

        }

    }
}

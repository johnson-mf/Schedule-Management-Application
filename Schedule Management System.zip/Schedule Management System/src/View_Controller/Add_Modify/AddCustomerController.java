package View_Controller.Add_Modify;

import DBAccess.DBCountries;
import DBAccess.DBCustomers;
import DBAccess.DBDivisions;
import Model.Countries;
import Model.Divisions;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class AddCustomerController implements Initializable {
    Stage stage;
    Parent scene;

    @FXML
    private TextField addressTextField;

    @FXML
    private TextField zipcodeTextField;

    @FXML
    private TextField phoneNumberTextField;

    @FXML
    private TextField customerNameTextField;

    @FXML
    private ComboBox<Countries> countryComboBox;

    @FXML
    private ComboBox<Divisions> divisionComboBox;

    /**This method goes back to the main screen*/
    @FXML
    void onActionCancel(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View_Controller/FXML/MainMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**This method takes the values in the date pickers, combo boxes, and textfields and uses a method in the DBACCESS package to
     * create the customer. The following values are taking in and saved to the mySQL database: Name, address, division, country,
     * zipcode, and phone number. If a user puts in the wrong value or forgets a value, a sql exception is thrown
     * and an error message appears to help guide the user to fix the mistake.*/
    @FXML
    void onActionMainMenu(ActionEvent event) throws IOException {
        try {
            String name = customerNameTextField.getText();
            String address = addressTextField.getText();
            Countries country = countryComboBox.getValue();
            Divisions division = divisionComboBox.getValue();
            String zipcode = zipcodeTextField.getText();
            String phone = phoneNumberTextField.getText();
            DBCustomers.createCustomer(name, address, division.getId(), zipcode, phone);


            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/View_Controller/FXML/MainMenu.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        }
        catch (NumberFormatException | IOException e){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText("Please enter the right values for the corresponding fields!");
            alert.showAndWait();
        }
    }


    /**This method is called when the country combo box value has been selected by the user. This allows the division combo box to be set
     * with the appropriate division names and ids for ease of access for the user.*/
    public void onCountry(ActionEvent event) {

        Countries countries = countryComboBox.getValue();

        ObservableList<Divisions> divisionsList = DBDivisions.getDivisionsByCountry(countries.getId());
        divisionComboBox.setItems(divisionsList);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        //making a list to set the combo boxes to
        ObservableList<Countries> countryList = DBCountries.getAllCountries();
        countryComboBox.setItems(countryList);




    }


}

package View_Controller.Add_Modify;

import DBAccess.*;
import Model.*;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Timestamp;
import java.time.*;
import java.util.ResourceBundle;
/**This class adds appointments.*/
public class AddAppointmentController implements Initializable {
    Stage stage;
    Parent scene;

    @FXML
    private TextField titleTextField;

    @FXML
    private TextField descriptionTextField;

    @FXML
    private TextField locationTextField;

    @FXML
    private TextField typeTextField;

    @FXML
    private ComboBox<LocalTime> startComboBox;

    @FXML
    private ComboBox<LocalTime> endComboBox;

    @FXML
    private ComboBox<Customers> customerIdComboBox;

    @FXML
    private ComboBox<Contacts> contactComboBox;

    @FXML
    private ComboBox<Users> userIdComboBox;

    @FXML
    private DatePicker datepicker;

    @FXML
    private  Label warningLabel;

    /**This method goes back to the main screen*/
    @FXML
    void onActionCancel(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View_Controller/FXML/MainMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**This method takes the values in the date pickers, combo boxes, and textfields and uses a method in the DBACCESS package to
     * create the appointment. The following values are taking in and saved to the mySQL database: UserID, CustomerID, Title, Description,
     * Location, ContactID, Type, Start and End times and dates. If a user puts in the wrong value or forgets a value, a sql exception is thrown
     * and an error message appears to help guide the user to fix the mistake.*/
    @FXML
    void onActionMainMenu(ActionEvent event) throws IOException {

       try{
           //Saving the appointment minute 40:00 the keys to keys

        Users userID = userIdComboBox.getValue();
        Customers customerID = customerIdComboBox.getValue();
        String title = titleTextField.getText();
        String description = descriptionTextField.getText();
        String location = locationTextField.getText();
        Contacts contactID = contactComboBox.getValue();
        String type = typeTextField.getText();
        LocalDate date = datepicker.getValue(); // returns date
        LocalTime start = startComboBox.getValue(); // returns start time
        LocalTime end = endComboBox.getValue(); // returns end time


        //Start time and end time:
        LocalDateTime startLocalDateTime = LocalDateTime.of(date,start);
        LocalDateTime endLocalDateTime = LocalDateTime.of(date,end);
        int currentCustomer =customerIdComboBox.getValue().getId();

        ObservableList <Appointments> appointmentsList = DBAppointments.getAllAppointments();
        for (Appointments appointments: appointmentsList) {
            LocalDateTime existingStart = appointments.getStart();
            LocalDateTime existingEnd = appointments.getEnd();
            if (currentCustomer == appointments.getAppointmentCustomerID()) {

                if (startLocalDateTime.isAfter(existingStart.minusMinutes(1)) && startLocalDateTime.isBefore(existingEnd)) {
                    warningLabel.setText("Appointment ID:" + appointments.getAppointmentID() + " with a start time of " + appointments.getStart() + " and an end time of  : " + appointments.getEnd() + " already exists.");
                    return;
                }
                if (endLocalDateTime.isAfter(existingStart) && endLocalDateTime.isBefore(existingEnd.plusMinutes(1))) {
                    warningLabel.setText("Appointment ID:" + appointments.getAppointmentID() + " with a start time of " + appointments.getStart() + " and an end time of  : " + appointments.getEnd() + " already exists.");
                    return;
                }
                if (startLocalDateTime.isBefore(existingStart) && endLocalDateTime.isAfter(existingEnd.plusMinutes(1))) {
                    warningLabel.setText("Appointment ID:" + appointments.getAppointmentID() + " with a start time of " + appointments.getStart() + " and an end time of  : " + appointments.getEnd() + " already exists.");
                    return;
                }
            }
        }
       //DBAppointments.createAppointment(user.getId(),customer.getId(),title,description,location,contact.getId(),type);
        DBAppointments.createAppointment(title,description,location,type,Timestamp.valueOf(startLocalDateTime),Timestamp.valueOf(endLocalDateTime),customerID.getId(),userID.getId(),contactID.getId());



        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View_Controller/FXML/MainMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

       }catch (NumberFormatException | IOException e){
           Alert alert = new Alert(Alert.AlertType.ERROR);
           alert.setTitle("Error");
           alert.setContentText("Please enter the right values for the corresponding fields!");
           alert.showAndWait();
       }
    }

        @Override
        public void initialize (URL url, ResourceBundle resourceBundle){

            //making a list to set the combo boxes to
            ObservableList<Users> userList = DBUsers.getAllUsers();
            userIdComboBox.setItems(userList);

            //making a list to set the combo boxes to
            ObservableList<Customers> customerList = DBCustomers.getAllCustomers();
            customerIdComboBox.setItems(customerList);

            //making a list to set the combo boxes to
            ObservableList<Contacts> contactsList = DBContacts.getAllContacts();
            contactComboBox.setItems(contactsList);


            ZoneId utcZoneID = ZoneId.of("UTC");
            ZoneId userZoneID = ZoneId.systemDefault();

            //create utc local dates and times
            LocalDate utcDate = LocalDate.of(2020,05,06);

            LocalTime utcStartTime =LocalTime.of(12,00);
            LocalTime utcEndTime =LocalTime.of(2,00);

            //turn them into local date times
            LocalDateTime utcStartLocalDateTime = LocalDateTime.of(utcDate,utcStartTime);
            LocalDateTime utcEndLocalDateTime = LocalDateTime.of(utcDate,utcEndTime);

            //turn them into utc zoned date times
            ZonedDateTime utcStartZonedDateTime = ZonedDateTime.of(utcStartLocalDateTime,utcZoneID);
            ZonedDateTime utcEndZonedDateTime = ZonedDateTime.of(utcEndLocalDateTime,utcZoneID);


            //convert utc zoned start and end times to the system default time
            ZonedDateTime systemStartZonedDateTime = ZonedDateTime.ofInstant(utcStartZonedDateTime.toInstant(),userZoneID);
            ZonedDateTime systemEndZonedDateTime = ZonedDateTime.ofInstant(utcEndZonedDateTime.toInstant(),userZoneID);

            //convert system start zoned times to local date times
            LocalDateTime systemStartLocalDateTime = LocalDateTime.ofInstant(systemStartZonedDateTime.toInstant(),userZoneID);
            LocalDateTime systemEndLocalDateTime = LocalDateTime.ofInstant(systemEndZonedDateTime.toInstant(),userZoneID);




            LocalTime start = systemStartLocalDateTime.toLocalTime();
            LocalTime end = systemEndLocalDateTime.toLocalTime();

            //local time
            while(start.isBefore(end.plusSeconds(1))){
                startComboBox.getItems().add(start);
                endComboBox.getItems().add(start);
                start = start.plusMinutes(15);
            }

        }
    }

/* //Saving the appointment minute 40:00 the keys to keys

           Users userID = userIdComboBox.getValue();
           Customers customerID = customerIdComboBox.getValue();
           String title = titleTextField.getText();
           String description = descriptionTextField.getText();
           String location = locationTextField.getText();
           Contacts contactID = contactComboBox.getValue();
           String type = typeTextField.getText();
           LocalDate date = datepicker.getValue(); // returns date
           LocalTime start = startComboBox.getValue(); // returns start time
           LocalTime end = endComboBox.getValue(); // returns end time


           //Start time and end time:
           LocalDateTime startLocalDateTime = LocalDateTime.of(date, start);
           LocalDateTime endLocalDateTime = LocalDateTime.of(date, end);

           ObservableList<Appointments> appointmentsList = DBAppointments.getAllAppointments();
           for (Appointments appointments : appointmentsList) {
               LocalDateTime existingStart = appointments.getStart();
               LocalDateTime existingEnd = appointments.getEnd();

               if (startLocalDateTime.isAfter(existingStart) && startLocalDateTime.isBefore(existingEnd)) {
                   warningLabel.setText("Appointment ID:" + appointments.getAppointmentID() + " with a start time of " + appointments.getStart() + " and and end time of  : " + appointments.getEnd() + " already exists.");
                   return;
               }
               if (endLocalDateTime.isAfter(existingStart) && endLocalDateTime.isBefore(existingEnd)) {
                   warningLabel.setText("Appointment ID:" + appointments.getAppointmentID() + " with a start time of " + appointments.getStart() + " and and end time of  : " + appointments.getEnd() + " already exists.");
                   return;
               }
               //DBAppointments.createAppointment(user.getId(),customer.getId(),title,description,location,contact.getId(),type);
               DBAppointments.createAppointment(title, description, location, type, Timestamp.valueOf(startLocalDateTime), Timestamp.valueOf(endLocalDateTime), customerID.getId(), userID.getId(), contactID.getId());


               stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
               scene = FXMLLoader.load(getClass().getResource("/View_Controller/MainMenu.fxml"));
               stage.setScene(new Scene(scene));
               stage.show();

           }catch(NumberFormatException | IOException e){
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setTitle("Error");
               alert.setContentText("Please enter the right values for the corresponding fields!");
               alert.showAndWait();
           }
       }*/
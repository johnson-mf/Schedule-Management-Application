package View_Controller;

import Interface.TimeZone;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;


import java.io.*;
import java.io.PrintWriter;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Locale;
import java.util.ResourceBundle;

/**This is the log in screen. It implements one of the two lambda expressions, in the initialize method. */
public class LoginController implements Initializable {
    Stage stage;
    Parent scene;

    @FXML
    private Label loginLabel;

    @FXML
    private Label usernameLabel;

    @FXML
    private Label passwordLabel;

    @FXML
    private TextField usernameTextField;

    @FXML
    private TextField passwordTextField;

    @FXML
    private Button logInBtn;

    @FXML
    private Label timezoneLabel;


    /**This is the gate way intot he application. OIf the user enters the username and password correctly, they are taken to the mainscreen in the
     * schediling app. All log in attempts are documented and saved to a text file in the Files package in the src file. In the text file, you will find
     * The time, date, and whether or not access was granted to the user or not. */
    @FXML
    void onActionMainMenu(ActionEvent event) throws IOException {


        String loginTXT = "src/File/login_activity.txt", attempt;
        //changes language to french on log in screen
        ResourceBundle rb = ResourceBundle.getBundle("Model/Nat", Locale.getDefault());


        //create file write object
        FileWriter fwriter = new FileWriter(loginTXT,true);
        //create and open file
        PrintWriter outputFile = new PrintWriter(fwriter);
        //get items and write to file




            if(usernameTextField.getText().equals("test") && passwordTextField.getText().equals("test")){


                LocalTime currentTime = LocalTime.now();
                LocalDate currentDate = LocalDate.now();
                String attemptedUser = usernameTextField.getText();
                attempt = "Access: Granted     UserName: " + attemptedUser +"     Time: " + currentTime + "    Date:" + currentDate;
                System.out.println(attempt);
                outputFile.println(attempt);
                outputFile.close();
                stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                scene = FXMLLoader.load(getClass().getResource("/View_Controller/FXML/MainMenu.fxml"));
                stage.setScene(new Scene(scene));
                stage.show();

            } else {
                Locale.getDefault().getLanguage();
                timezoneLabel.setText(rb.getString("Invalid") + " " + rb.getString("Credentials"));
                LocalTime currentTime = LocalTime.now();
                LocalDate currentDate = LocalDate.now();
                String attemptedUser = usernameTextField.getText();
                attempt = "Access: Denied     Username: " + attemptedUser +"     Time: " + currentTime + "    Date:" + currentDate;
                System.out.println(attempt);
                outputFile.println(attempt);
                outputFile.close();
        }

    }

/**This is where the first lambda expression is used. It is able to get the Zone ID thats default to the whatever system the user is using.*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        //new parameter lambda expression
        TimeZone message = () -> String.valueOf(ZoneId.systemDefault());
        timezoneLabel.setText(message.displayMessage());


        //changes language to french on log in screen
        ResourceBundle rb = ResourceBundle.getBundle("Model/Nat", Locale.getDefault());

        if(Locale.getDefault().getLanguage().equals("fr")){
            loginLabel.setText(rb.getString("Login"));
            usernameLabel.setText(rb.getString("username"));
            passwordLabel.setText(rb.getString("password"));
            logInBtn.setText(rb.getString("signin"));
        }
    }

}
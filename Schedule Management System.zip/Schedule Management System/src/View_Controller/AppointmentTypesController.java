package View_Controller;

import DBAccess.DBAppointments;
import Model.Appointments;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.Month;
import java.util.ResourceBundle;

public class AppointmentTypesController implements Initializable {

    Stage stage;
    Parent scene;

    @FXML
    private ToggleGroup yearToggleGroup;

    @FXML
    private TableView<Appointments> appointmentFormatTableView;

    @FXML
    private TableColumn<Appointments, String> appointmentFormatCol;
/**There are 12 methods here each named from a month in the year. When a user selects a radio button, the month correspoinding with that radio button
 * will be used to look in the database and show the appointment formats for the specified month. ALl appointments in the selected
 * month is listed.*/
    @FXML
    void onApril(ActionEvent event) {
        //create an empty array list and bring us our original array list,

        ObservableList<Appointments> monthAppointments = FXCollections.observableArrayList();

        ObservableList<Appointments>allAppointments = DBAppointments.getAllAppointments();

        //run a loop and and delete the parts that are in original list that are not in the selected list
        for (Appointments appointments : allAppointments) {
                //LocalDate appointmentDate = appointments.getStart().toLocalDate();
               // Month appointmentMonth = appointmentDate.getMonth();

                LocalDate compareMonth =LocalDate.of(2020,04,01);
                Month compareMonthObject = compareMonth.getMonth();
                LocalDate appointmentDay = appointments.getStart().toLocalDate();
                Month appointmentMonth =appointmentDay.getMonth();

                    if (appointmentMonth == compareMonthObject){
                        monthAppointments.add(appointments);
                        }
                    }
        System.out.println("Week appointments: "+monthAppointments);
        System.out.println("all appointments: "+ allAppointments);
        appointmentFormatTableView.setItems(monthAppointments);
        appointmentFormatCol.setCellValueFactory(new PropertyValueFactory<>("type"));

    }

    @FXML
    void onAugust(ActionEvent event) {
        //create an empty array list and bring us our original array list,

        ObservableList<Appointments> monthAppointments = FXCollections.observableArrayList();

        ObservableList<Appointments>allAppointments = DBAppointments.getAllAppointments();

        //run a loop and and delete the parts that are in original list that are not in the selected list
        for (Appointments appointments : allAppointments) {
            //LocalDate appointmentDate = appointments.getStart().toLocalDate();
            // Month appointmentMonth = appointmentDate.getMonth();

            LocalDate compareMonth =LocalDate.of(2020,8,01);
            Month compareMonthObject = compareMonth.getMonth();
            LocalDate appointmentDay = appointments.getStart().toLocalDate();
            Month appointmentMonth =appointmentDay.getMonth();

            if (appointmentMonth == compareMonthObject){
                monthAppointments.add(appointments);
            }
        }
        System.out.println("Week appointments: "+monthAppointments);
        System.out.println("all appointments: "+ allAppointments);
        appointmentFormatTableView.setItems(monthAppointments);
        appointmentFormatCol.setCellValueFactory(new PropertyValueFactory<>("type"));

    }

    @FXML
    void onDec(ActionEvent event) {
        //create an empty array list and bring us our original array list,

        ObservableList<Appointments> monthAppointments = FXCollections.observableArrayList();

        ObservableList<Appointments>allAppointments = DBAppointments.getAllAppointments();

        //run a loop and and delete the parts that are in original list that are not in the selected list
        for (Appointments appointments : allAppointments) {
            //LocalDate appointmentDate = appointments.getStart().toLocalDate();
            // Month appointmentMonth = appointmentDate.getMonth();

            LocalDate compareMonth =LocalDate.of(2020,12,01);
            Month compareMonthObject = compareMonth.getMonth();
            LocalDate appointmentDay = appointments.getStart().toLocalDate();
            Month appointmentMonth =appointmentDay.getMonth();

            if (appointmentMonth == compareMonthObject){
                monthAppointments.add(appointments);
            }
        }
        System.out.println("Week appointments: "+monthAppointments);
        System.out.println("all appointments: "+ allAppointments);
        appointmentFormatTableView.setItems(monthAppointments);
        appointmentFormatCol.setCellValueFactory(new PropertyValueFactory<>("type"));

    }

    @FXML
    void onFeb(ActionEvent event) {
        //create an empty array list and bring us our original array list,

        ObservableList<Appointments> monthAppointments = FXCollections.observableArrayList();

        ObservableList<Appointments>allAppointments = DBAppointments.getAllAppointments();

        //run a loop and and delete the parts that are in original list that are not in the selected list
        for (Appointments appointments : allAppointments) {
            //LocalDate appointmentDate = appointments.getStart().toLocalDate();
            // Month appointmentMonth = appointmentDate.getMonth();

            LocalDate compareMonth =LocalDate.of(2020,2,01);
            Month compareMonthObject = compareMonth.getMonth();
            LocalDate appointmentDay = appointments.getStart().toLocalDate();
            Month appointmentMonth =appointmentDay.getMonth();

            if (appointmentMonth == compareMonthObject){
                monthAppointments.add(appointments);
            }
        }
        System.out.println("Week appointments: "+monthAppointments);
        System.out.println("all appointments: "+ allAppointments);
        appointmentFormatTableView.setItems(monthAppointments);
        appointmentFormatCol.setCellValueFactory(new PropertyValueFactory<>("type"));

    }

    @FXML
    void onJan(ActionEvent event) {
        //create an empty array list and bring us our original array list,

        ObservableList<Appointments> monthAppointments = FXCollections.observableArrayList();

        ObservableList<Appointments>allAppointments = DBAppointments.getAllAppointments();

        //run a loop and and delete the parts that are in original list that are not in the selected list
        for (Appointments appointments : allAppointments) {
            //LocalDate appointmentDate = appointments.getStart().toLocalDate();
            // Month appointmentMonth = appointmentDate.getMonth();

            LocalDate compareMonth =LocalDate.of(2020,1,01);
            Month compareMonthObject = compareMonth.getMonth();
            LocalDate appointmentDay = appointments.getStart().toLocalDate();
            Month appointmentMonth =appointmentDay.getMonth();

            if (appointmentMonth == compareMonthObject){
                monthAppointments.add(appointments);
            }
        }
        System.out.println("Week appointments: "+monthAppointments);
        System.out.println("all appointments: "+ allAppointments);
        appointmentFormatTableView.setItems(monthAppointments);
        appointmentFormatCol.setCellValueFactory(new PropertyValueFactory<>("type"));

    }

    @FXML
    void onJuly(ActionEvent event) {
        //create an empty array list and bring us our original array list,

        ObservableList<Appointments> monthAppointments = FXCollections.observableArrayList();

        ObservableList<Appointments>allAppointments = DBAppointments.getAllAppointments();

        //run a loop and and delete the parts that are in original list that are not in the selected list
        for (Appointments appointments : allAppointments) {
            //LocalDate appointmentDate = appointments.getStart().toLocalDate();
            // Month appointmentMonth = appointmentDate.getMonth();

            LocalDate compareMonth =LocalDate.of(2020,07,01);
            Month compareMonthObject = compareMonth.getMonth();
            LocalDate appointmentDay = appointments.getStart().toLocalDate();
            Month appointmentMonth =appointmentDay.getMonth();

            if (appointmentMonth == compareMonthObject){
                monthAppointments.add(appointments);
            }
        }
        System.out.println("Week appointments: "+monthAppointments);
        System.out.println("all appointments: "+ allAppointments);
        appointmentFormatTableView.setItems(monthAppointments);
        appointmentFormatCol.setCellValueFactory(new PropertyValueFactory<>("type"));

    }

    @FXML
    void onJune(ActionEvent event) {
        //create an empty array list and bring us our original array list,

        ObservableList<Appointments> monthAppointments = FXCollections.observableArrayList();

        ObservableList<Appointments>allAppointments = DBAppointments.getAllAppointments();

        //run a loop and and delete the parts that are in original list that are not in the selected list
        for (Appointments appointments : allAppointments) {
            //LocalDate appointmentDate = appointments.getStart().toLocalDate();
            // Month appointmentMonth = appointmentDate.getMonth();

            LocalDate compareMonth =LocalDate.of(2020,6,01);
            Month compareMonthObject = compareMonth.getMonth();
            LocalDate appointmentDay = appointments.getStart().toLocalDate();
            Month appointmentMonth =appointmentDay.getMonth();

            if (appointmentMonth == compareMonthObject){
                monthAppointments.add(appointments);
            }
        }
        System.out.println("Week appointments: "+monthAppointments);
        System.out.println("all appointments: "+ allAppointments);
        appointmentFormatTableView.setItems(monthAppointments);
        appointmentFormatCol.setCellValueFactory(new PropertyValueFactory<>("type"));

    }

    @FXML
    void onMar(ActionEvent event) {
        //create an empty array list and bring us our original array list,

        ObservableList<Appointments> monthAppointments = FXCollections.observableArrayList();

        ObservableList<Appointments>allAppointments = DBAppointments.getAllAppointments();

        //run a loop and and delete the parts that are in original list that are not in the selected list
        for (Appointments appointments : allAppointments) {
            //LocalDate appointmentDate = appointments.getStart().toLocalDate();
            // Month appointmentMonth = appointmentDate.getMonth();

            LocalDate compareMonth =LocalDate.of(2020,3,01);
            Month compareMonthObject = compareMonth.getMonth();
            LocalDate appointmentDay = appointments.getStart().toLocalDate();
            Month appointmentMonth =appointmentDay.getMonth();

            if (appointmentMonth == compareMonthObject){
                monthAppointments.add(appointments);
            }
        }
        System.out.println("Week appointments: "+monthAppointments);
        System.out.println("all appointments: "+ allAppointments);
        appointmentFormatTableView.setItems(monthAppointments);
        appointmentFormatCol.setCellValueFactory(new PropertyValueFactory<>("type"));

    }

    @FXML
    void onMay(ActionEvent event) {
        //create an empty array list and bring us our original array list,

        ObservableList<Appointments> monthAppointments = FXCollections.observableArrayList();

        ObservableList<Appointments>allAppointments = DBAppointments.getAllAppointments();

        //run a loop and and delete the parts that are in original list that are not in the selected list
        for (Appointments appointments : allAppointments) {
            //LocalDate appointmentDate = appointments.getStart().toLocalDate();
            // Month appointmentMonth = appointmentDate.getMonth();

            LocalDate compareMonth =LocalDate.of(2020,5,01);
            Month compareMonthObject = compareMonth.getMonth();
            LocalDate appointmentDay = appointments.getStart().toLocalDate();
            Month appointmentMonth =appointmentDay.getMonth();

            if (appointmentMonth == compareMonthObject){
                monthAppointments.add(appointments);
            }
        }
        System.out.println("Week appointments: "+monthAppointments);
        System.out.println("all appointments: "+ allAppointments);
        appointmentFormatTableView.setItems(monthAppointments);
        appointmentFormatCol.setCellValueFactory(new PropertyValueFactory<>("type"));

    }

    @FXML
    void onNov(ActionEvent event) {
        //create an empty array list and bring us our original array list,

        ObservableList<Appointments> monthAppointments = FXCollections.observableArrayList();

        ObservableList<Appointments>allAppointments = DBAppointments.getAllAppointments();

        //run a loop and and delete the parts that are in original list that are not in the selected list
        for (Appointments appointments : allAppointments) {
            //LocalDate appointmentDate = appointments.getStart().toLocalDate();
            // Month appointmentMonth = appointmentDate.getMonth();

            LocalDate compareMonth =LocalDate.of(2020,11,01);
            Month compareMonthObject = compareMonth.getMonth();
            LocalDate appointmentDay = appointments.getStart().toLocalDate();
            Month appointmentMonth =appointmentDay.getMonth();

            if (appointmentMonth == compareMonthObject){
                monthAppointments.add(appointments);
            }
        }
        System.out.println("Week appointments: "+monthAppointments);
        System.out.println("all appointments: "+ allAppointments);
        appointmentFormatTableView.setItems(monthAppointments);
        appointmentFormatCol.setCellValueFactory(new PropertyValueFactory<>("type"));

    }

    @FXML
    void onOnct(ActionEvent event) {
        //create an empty array list and bring us our original array list,

        ObservableList<Appointments> monthAppointments = FXCollections.observableArrayList();

        ObservableList<Appointments>allAppointments = DBAppointments.getAllAppointments();

        //run a loop and and delete the parts that are in original list that are not in the selected list
        for (Appointments appointments : allAppointments) {
            //LocalDate appointmentDate = appointments.getStart().toLocalDate();
            // Month appointmentMonth = appointmentDate.getMonth();

            LocalDate compareMonth =LocalDate.of(2020,10,01);
            Month compareMonthObject = compareMonth.getMonth();
            LocalDate appointmentDay = appointments.getStart().toLocalDate();
            Month appointmentMonth =appointmentDay.getMonth();

            if (appointmentMonth == compareMonthObject){
                monthAppointments.add(appointments);
            }
        }
        System.out.println("Week appointments: "+monthAppointments);
        System.out.println("all appointments: "+ allAppointments);
        appointmentFormatTableView.setItems(monthAppointments);
        appointmentFormatCol.setCellValueFactory(new PropertyValueFactory<>("type"));

    }

    @FXML
    void onSep(ActionEvent event) {
        //create an empty array list and bring us our original array list,

        ObservableList<Appointments> monthAppointments = FXCollections.observableArrayList();

        ObservableList<Appointments>allAppointments = DBAppointments.getAllAppointments();

        //run a loop and and delete the parts that are in original list that are not in the selected list
        for (Appointments appointments : allAppointments) {
            //LocalDate appointmentDate = appointments.getStart().toLocalDate();
            // Month appointmentMonth = appointmentDate.getMonth();

            LocalDate compareMonth =LocalDate.of(2020,9,01);
            Month compareMonthObject = compareMonth.getMonth();
            LocalDate appointmentDay = appointments.getStart().toLocalDate();
            Month appointmentMonth =appointmentDay.getMonth();

            if (appointmentMonth == compareMonthObject){
                monthAppointments.add(appointments);
            }
        }
        System.out.println("Week appointments: "+monthAppointments);
        System.out.println("all appointments: "+ allAppointments);
        appointmentFormatTableView.setItems(monthAppointments);
        appointmentFormatCol.setCellValueFactory(new PropertyValueFactory<>("type"));

    }

    /**This method goes back to the main menu.*/
    @FXML
    void onActionMainMenu(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View_Controller/FXML/MainMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}

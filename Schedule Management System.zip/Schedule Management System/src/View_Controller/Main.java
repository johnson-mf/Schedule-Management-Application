package View_Controller;

import DBAccess.DBAppointments;
import Database.DBConnection;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXML/MainMenu.fxml"));
        primaryStage.setTitle("Consultant Scheduler");
        primaryStage.setScene(new Scene(root, 900, 600));
        primaryStage.show();
    }

/**Where everything starts...*/
    public static void main(String[] args) throws SQLException, IOException {


        //start the DB connection
        DBConnection.startConnection();
        //Connect to database
        Connection conn = DBConnection.getConnection();

        DBAppointments.getAppointmentMessage();
            launch(args);

            //close the connection
            DBConnection.closeConnection();

        }

    }
/*  //HOW TO READ TEXT FILES
        String fileName = "groceries.txt", item;
        //create file object
        File file = new File(fileName);
        //create scanner object
        Scanner inputFile = new Scanner(file);
        //read all lines from the file
        while(inputFile.hasNext()){
            item = inputFile.nextLine();
            System.out.println(item);
        }
        //close file
        inputFile.close();
        System.out.println("date read");
//HOW TO WRITE TO FILES
        String readMeTXT = "src/File/groceries.txt", item;

        //create scanner object
        Scanner keyboard = new Scanner(System.in);

        //get item count
        System.out.print("How many items do you have?");
        int itemCount = keyboard.nextInt();
        //clear keyboard buffer after using nextInt
        keyboard.nextLine();
        //create file write object
        FileWriter fwritter = new FileWriter(readMeTXT,true);
        //create and open file
        PrintWriter outputFile = new PrintWriter(fwritter);
        //get items and write to file
        for (int i = 0; i < itemCount; i++){
            System.out.print("Enter item "+ (i + 1) + ":" );
            item = keyboard.nextLine();
            outputFile.println(item);
        }
        // close file
        outputFile.close();;
        System.out.println("File written and closed."); //files names
        String readMeTXT = "groceries.txt", item;

        //create scanner object
        Scanner keyboard = new Scanner(System.in);

        //get item count
        System.out.print("How many items do you have?");
        int itemCount = keyboard.nextInt();
        //clear keyboard buffer after using nextInt
        keyboard.nextLine();
            //create and open file
        PrintWriter outputFile = new PrintWriter(readMeTXT);
        //get items and write to file
        for (int i = 0; i < itemCount; i++){
            System.out.print("Enter item "+ (i + 1) + ":" );
            item = keyboard.nextLine();
            outputFile.println(item);
        }
        // close file
        outputFile.close();;
        System.out.println("File written and closed.");
        LocalDateTime startLDT = LocalDateTime.of(2021,5,7,20,0);
        LocalDateTime endLDT = LocalDateTime.of(2021,5,7,20,30);
        LocalDateTime compareLDT = LocalDateTime.of(2021,5,7,20,15);
        //Check time overlap
        if(compareLDT.isAfter(startLDT) && compareLDT.isBefore(endLDT)){
            System.out.println(compareLDT +" is after " + startLDT + " but before " + endLDT);
        }
        LocalTime startTime = LocalTime.of(0,10);
        LocalTime currentTime =LocalTime.now();
        //time difference in minutes
        long timeDifference = ChronoUnit.MINUTES.between(startTime,currentTime);
        long interval = (timeDifference + -1) * -1;

         if(interval> 0 && interval <=15){
             System.out.println("You have an event in " + interval + "minutes");
         }else if (interval <= 1){
             System.out.println("You had an event " + interval + "minutes ago");
         }

            TimeZone square = n -> n * n;
            //System.out.println(square.caculateSquaren(5));*/

        /*System.out.println(ZoneId.systemDefault());
        //ZoneId.getAvailableZoneIds().stream().sorted().forEach(System.out::println);
        //ZoneId.getAvailableZoneIds().stream().filter(z->z.contains("America")).sorted().forEach(System.out::println);
        LocalDate seattleDate = LocalDate.of(2020,05,06);
        LocalTime seattleTime =LocalTime.of(9,00);
        LocalDateTime seattle = LocalDateTime.of(seattleDate,seattleTime);
        ZoneId seattleZoneId = ZoneId.systemDefault();

        //my local zoned date time
        ZonedDateTime seattleZDT = ZonedDateTime.of(seattle,seattleZoneId);

        //conversion from local time to UTC
        //must specify destination zone id
        ZoneId utcZoneID = ZoneId.of("UTC");
        System.out.println(utcZoneID);

        //new utc zone date time is taken from your local zone date time
        ZonedDateTime utcZDT =ZonedDateTime.ofInstant(seattleZDT.toInstant(),utcZoneID);
        System.out.println(utcZDT);

        //convert from utc to local date time
        LocalDateTime backToLDT = LocalDateTime.ofInstant(utcZDT.toInstant(),seattleZoneId);
        System.out.println(backToLDT);

        //System.out.println(seattleZDT.toL);//date time/ offset / zone id location
         //SHOW ALL COUNTRIES
        String selectStatement = "SELECT * FROM countries";

        DBQuery.setPreparedStatement(conn, selectStatement);// create prepared statement
        PreparedStatement ps = DBQuery.getPreparedStatement();// get a reference to use in the controller
        ps.execute();//execute prepared statement
        ResultSet rs = ps.getResultSet();
        while (rs.next()) {
            int countryID = rs.getInt("Country_ID");
            String countryName = rs.getString("Country");
            LocalDate date = rs.getDate("Create_Date").toLocalDate();//must convert to local date because getDate & getTime are outdated
            LocalTime time = rs.getTime("Create_Date").toLocalTime();
            String createdBy = rs.getString("Created_By");
            LocalDateTime lastUpdate = rs.getTimestamp("Last_Update").toLocalDateTime();
            //Display record
            System.out.println(countryID + countryName + date + time + createdBy + lastUpdate);
        /INSERT

        String insertStatement = "INSERT INTO countries(Country,Create_Date,Created_BY,Last_Updated_By) VALUES(?,?,?,?)";
        DBQuery.setPreparedStatement(conn,insertStatement);// create prepared statement
        PreparedStatement ps = DBQuery.getPreparedStatement();// get a reference to use in the controller
        String countryName;
        String createDate = "2021-04-27 00:00:00";
        String createdBy = "Admin";
        String lastUpdateBy = "Admin";

        Scanner keyboard = new Scanner(System.in);// keyboard input
        System.out.print("enter a country");
        countryName = keyboard.nextLine();

        ps.setString(1,countryName);
        ps.setString(2,createDate);
        ps.setString(3,createdBy);
        ps.setString(4,lastUpdateBy);

        ps.execute();//execute prepared statement

        //UPDATE
        String updateStatement = "UPDATE countries SET Country = ?, Created_By = ? WHERE Country = ?";

        DBQuery.setPreparedStatement(conn,updateStatement);// create prepared statement
        PreparedStatement ps = DBQuery.getPreparedStatement();// get a reference to use in the controller
        String countryName, newCountry, createdBy;

        Scanner keyboard = new Scanner(System.in);// keyboard input

        System.out.print("enter a country 2 update");
        countryName = keyboard.nextLine();
        System.out.print("enter a new country");
        newCountry = keyboard.nextLine();
        System.out.print("enter a user");
        createdBy = keyboard.nextLine();

        ps.setString(1,newCountry);
        ps.setString(2,createdBy);
        ps.setString(3,countryName);

        ps.execute();//execute prepared statement

//delete
        String deleteStatement = "DELETE FROM countries WHERE Country = ?";

        DBQuery.setPreparedStatement(conn,deleteStatement);// create prepared statement
                PreparedStatement ps = DBQuery.getPreparedStatement();// get a reference to use in the controller
                String countryName;

                Scanner keyboard = new Scanner(System.in);// keyboard input

                System.out.print("enter a country 2 delete");
                countryName = keyboard.nextLine();

                ps.setString(1,countryName);


                ps.execute();//execute prepared statement

                if(ps.getUpdateCount()>0)
                System.out.println(ps.getUpdateCount() + " rows affected");
                else
                System.out.println("No change"); */

            // A WAY TO DISPLAY TABLE VALUES forward scroll resultset
 /*       while (rs.next()){
            int countryID = rs.getInt("Country_ID");
            String countryName = rs.getString("Country");
            LocalDate date = rs.getDate("Create_Date").toLocalDate();//must convert to local date because getDate & getTime are outdated
            LocalTime time = rs.getTime("Create_Date").toLocalTime();
            String createdBy = rs.getString("Created_By");
            LocalDateTime lastUpdate = rs.getTimestamp("Last_Update").toLocalDateTime();
            //Display record
            System.out.println(countryID+countryName+date+time+createdBy+lastUpdate);
extra shit

        //create statement object
        DBQuery.setStatement(conn);
        //get statement reference
        Statement statement = DBQuery.getStatement();


        try {
            statement.execute(insertStatement);

    }catch(
    Exception e)

    {
        System.out.println(e.getMessage());
    }

*/
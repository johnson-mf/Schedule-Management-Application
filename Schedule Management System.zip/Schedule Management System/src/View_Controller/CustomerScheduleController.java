package View_Controller;

import DBAccess.DBAppointments;
import DBAccess.DBCustomers;
import Model.Appointments;
import Model.Customers;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ResourceBundle;
/**This class shows the customer appointment schedules*/
public class CustomerScheduleController implements Initializable {
    Stage stage;
    Parent scene;

    @FXML
    private ComboBox<Customers> customerComboBox;

    @FXML
    private TableView<Appointments> consultantTableView;

    @FXML
    private TableColumn<Appointments, Integer> appointmentIdCol;


    @FXML
    private TableColumn<Appointments, Integer> userIdCol;

    @FXML
    private TableColumn<Appointments, String> titleCol;

    @FXML
    private TableColumn<Appointments, String> descriptionCol;

    @FXML
    private TableColumn<Appointments, String> typeCol;

    @FXML
    private TableColumn<Appointments, LocalDateTime> startCol;

    @FXML
    private TableColumn<Appointments, LocalDateTime> endCol;

    /**This method goes back to the main screen*/
    @FXML
    void onActionMainMenu(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/View_Controller/FXML/MainMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**This method is triggered when the user chooses an customer id from the combo box. The tableview is then populated with
     * appointments and the corresponding data, including the appointment ID, appointment user id,
     * title, description, type, and start and end times and dates for the customer that is selected.*/
    @FXML
    void onCustomer(ActionEvent event) {
        Customers customers = customerComboBox.getValue();
        ObservableList<Appointments> appointmentList = DBAppointments.getAppointmentsByCustomer(customers.getId());
        consultantTableView.setItems(appointmentList);

        appointmentIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        userIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentUserID"));
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        typeCol.setCellValueFactory(new PropertyValueFactory<>("type"));
        startCol.setCellValueFactory(new PropertyValueFactory<>("start"));
        endCol.setCellValueFactory(new PropertyValueFactory<>("end"));
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<Customers> customerList = DBCustomers.getAllCustomers();
        customerComboBox.setItems(customerList);
    }
}
